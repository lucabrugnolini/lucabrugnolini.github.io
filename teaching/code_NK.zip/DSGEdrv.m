% PhD in Economics Law and Institutions 
% Introduction to DSGE 
% Luisa Corrado / Luca Brugnolini
% January 2015
% King and Watson Toolkit
% Setting up the file DRIVER.M

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% The driving system has the form:
%
%         x(t) = Q delta(t)
%         delta(t) = RHO * delta(t-1) + Gi e(t)
%
% where x(t) is the vector of exogenous variables and delta(t) is the 
% vector of exogenous state variables. 

% Setting Q, RHO and Gi
% The matrix Q is used for the correlation between shocks

nx = 2;
ndelta = nx;
nshock = nx;
Q = eye(nx);
Gi = eye(nx);  

% Calibration of shocks 

rho1 = 0.9;    % Production
rho2 = 0.5;     % Monetary

sig1 = 0.0072;  % Production
sig2 = 0.25;  % Monetary

%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity analysis  %  => Start here, do not delete
%%%%%%%%%%%%%%%%%%%%%%%%% 

if ~exist('dsgemsens.mat')==0 
	load dsgemsens;
	eval([senspara '=' num2str(paravalue)]);
end 

%%%%%%%%%%%%%%%%%%%%%%%%%
% Sensitivity analysis  %  => End here, do not delete
%%%%%%%%%%%%%%%%%%%%%%%%%

RHO = diag([rho1 rho2]); 
VCM = diag([sig1 sig2].^2); 

save drvrcm VCM RHO

% We now convert RHO and Q so that the VAR error vector of the converted
% system has an identity covariance Matrix. 
%				
% To do the transformation, write the driving system specified above as:
%
%   			x(t) = [Q*inv(B)]*[B*delta(t)]
%   			B*delta(t) = B*RHO*(inv(B))*B*delta(t-1) + B*Gi*e(t)
%
% where B*Gi*e(t) = G*u(t) where u(t) is an i.i.d random vector with unit
% variance and E[G*u(t)*u(t)'*G']=I. Hence, G=I, which is how we calibrate G
% below.

% Transformation

R=sqrtm(VCM);					% R is such that R'*R=VCM
B=inv(R');						% b/c E[B*VCM*B']=inv(R')*R'*R*inv(R)=I by definition
Q=Q*inv(B);
RHO=B*RHO*(inv(B));

% Initialize G matrix
%
% Note: G is not required for resolkw.m itself. However, the
% moments program requires it to be defined as all
% zeros with its upper block set to identity.

G = eye(nx);

% Note: 	We would have obtained exactly the same results in terms of solution and
%			dynamics between the different variables if we had put G=R'. The advantage 
%			of converting the system as above is that because G is now identity, we can 
%			easily compute IRFs with respect to a 1% innovation in the
%			exogenous variables