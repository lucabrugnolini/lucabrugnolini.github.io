% PhD in Economics Law and Institutions 
% Introduction to DSGE 
% Luisa Corrado / Luca Brugnolini
% January 2015
% King and Watson Toolkit
% Setting up the file CON.M
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% IMPORTANT: below program builds on parameter values that need to be manually 
% defined in system.m and driver.m files.

clear all;
pause off; 

%-------------------------------------------------------------
% Step 1: run the solution program, with defined tracking option
%-------------------------------------------------------------
track=0;

[M,PI,G,Q,ylist,xlist,lpd]=resolkw('DSGEsys','DSGEdrv',track);
save LBmodelsol M PI G Q ylist xlist lpd
pause 

%-------------------------------------------------------------
% Step 2: compute and graph impulse response function to shock
%-------------------------------------------------------------
[IR,shk]=impkw(M,PI,G,ylist,xlist,lpd);
save ir IR
%IR(:,2:end)=IR(:,2:end)*100; % This is for 1 S.D of shock deviation from steady state
IR(:,2:end)=IR(:,2:end)/abs(IR(1,1+rows(ylist)-length(lpd)+shk)); % This is for (+/-)1% deviation in magnitude
load indexes				        % load index information
slist=[ylist(lpd,:); xlist];		% create list of state variables
[T,K]=size(IR);
IR = [zeros(1,K); IR]; 
date=IR(2:end,1); 

load indexes                     
             
subplot(2,2,1),	plot(date,IR(2:end,1+ii),'b-','LineWidth',3); axis([1 T-1 min(IR(2:end,1+ii)) max(IR(2:end,1+ii))]);
               title(['Nominal Interest Rate' ],'FontSize',10, 'FontWeight', 'bold');
               hold on;
               xlabel('Quarters', 'FontSize', 9, 'FontAngle','italic', 'FontWeight', 'bold');
               ylabel('Deviations in %', 'FontSize', 9, 'FontAngle','italic', 'FontWeight', 'bold');                           
          
subplot(2,2,2),	plot(date,IR(2:end,1+ipi),'b-','LineWidth',3); axis([1 T-1 min(IR(2:end,1+ipi)) max(IR(2:end,1+ipi))]);
               title(['Inflation' ],'FontSize',10, 'FontWeight', 'bold');
               hold on;                
               xlabel('Quarters', 'FontSize', 9, 'FontAngle','italic', 'FontWeight', 'bold');               
               ylabel('Deviations in %', 'FontSize', 9, 'FontAngle','italic', 'FontWeight', 'bold');
              
subplot(2,2,3),	plot(date,IR(2:end,1+iy),'b-','LineWidth',3); axis([1 T-1 min(IR(2:end,1+iy)) max(IR(2:end,1+iy))]);
               title(['Output' ],'FontSize',10, 'FontWeight', 'bold');
               hold on;              
               xlabel('Quarters', 'FontSize', 9, 'FontAngle','italic', 'FontWeight', 'bold');
                ylabel('Deviations in %', 'FontSize', 9, 'FontAngle','italic', 'FontWeight', 'bold');

subplot(2,2,4),	plot(date,IR(2:end,1+iyg),'b-','LineWidth',3); axis([1 T-1 min(IR(2:end,1+iyg)) max(IR(2:end,1+iyg))]);
               title(['Output Gap' ],'FontSize',10, 'FontWeight', 'bold');
               hold on;              
               xlabel('Quarters', 'FontSize', 9, 'FontAngle','italic', 'FontWeight', 'bold');
                ylabel('Deviations in %', 'FontSize', 9, 'FontAngle','italic', 'FontWeight', 'bold');
            
%------------------------------------------------------------
%Step 3: compute second moments and display in table
%------------------------------------------------------------

lags=0;

FACV=fdfkw(M,PI,G,lags);		

rPI=rows(PI);

TAB=momentcalc(FACV,M,rPI,lags,ylist,xlist);               