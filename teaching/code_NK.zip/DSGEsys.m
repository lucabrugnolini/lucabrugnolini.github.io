
% PhD in Economics Law and Institutions 
% Introduction to DSGE 
% Luisa Corrado / Luca Brugnolini
% April 2016
% King and Watson Toolkit
% Setting up the file SYSTEM.M

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 1: input the various parameter values% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Parameters 
sigma = 1;
varphi = 1;
beta = 0.99;
phipi = 1.5;
phiy=0.5/4;
epsilon=6;
alpha=1/3;
theta=2/3;
bigtheta=(1-alpha)/(1-alpha+alpha*epsilon);
lambda=bigtheta*(1-theta)*(1-beta*theta)/theta;
kappa=lambda*(sigma+((varphi+alpha)/(1-alpha)));
psi_ya=(varphi+1)/(sigma*(1-alpha)+(varphi+alpha));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 2: Dimension of model system (to initialize matrices)
% A  is ny x ny
% B  is ny x ny
% CF is ny x nx*(nlead+1) since it is C0, C1, ... Cnlead 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ny    = 7; 
nx    = 2; 
nlead = 1; 

% Standard coding 

A=zeros(ny,ny);
B=zeros(ny,ny); 
CF=zeros(ny,nx*(nlead+1)); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 3A: setup lists of endogenous and exogenous variables
% (these lists should have equal length and no space on right!)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ylist=[
      'c   '   %1
      'y   '   %2
      'r   '   %3
      'pi  '   %4
      'i   '   %5
      'il  '   %6
      'iyg '   %6
             ];      
  
   xlist=[ 
      'Prod'   %1
      'Inte'   %2
      ];     
  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 3B: specify location of predetermined variables 
% Which are the variables ending with l = lagged
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lpd = [6]; 

% It is frequently convenient to define variable indicators
% with ready economic interpretation for the purpose of 
% setting up model equations.

% The indexes for the vector of endogenous variables are: 
ic    = 1; 
iy    = 2; 
ir    = 3;
ipi   = 4;
ii    = 5;
iil   = 6;
iyg  =7;



% Index for the exogenous variable 
% Shock
ixA=1; ixB=2;

% Saving of indexes (optional) for later use
% e.g., in plotting programs. 

save indexes.mat ... 
ic iy ir ipi ii iil iyg ...  
ixA  ixB...

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 4: set up the model equations, one at a time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Equation #1 Euler Equation
% -c_{t+1} -1/sigma*pi_{t+1} = -c_t -1/sigma*i_t 

ieqn = 1; 

A(ieqn, ic)       = -1;
A(ieqn, ipi)       = -1/sigma;
B(ieqn, ic)      = -1;
B(ieqn, ii)      = -1/sigma;


% Equation #2 Philips
% 0 = -pi_t + beta*pi_t+1 + kappa*(y_t-psi_ya*a_t)
ieqn = 2; 
 
B(ieqn, ipi)     = -1;
A(ieqn, ipi)     = -beta;
B(ieqn, iy)     = kappa;
CF(ieqn, ixA)   = -kappa*psi_ya; 


% Equation #3 Goods Market Clearing
% 0 = c_t - y_t
ieqn = 3;

B(ieqn, ic)     = -1;
B(ieqn, iy)     = 1;



% Equation #4 Feedback Rule
% 0 = -i_t + phipi*pi_t +  phiy*(y_t-psi_ya*a_t)+ e1_t
ieqn = 4;

B(ieqn, ii)     = -1;
B(ieqn, ipi)     = phipi;
B(ieqn, iy)      = phiy;
CF(ieqn, ixA)   = -phiy*psi_ya; 
CF(ieqn, ixB)   = 1;
 

% Equation #5 Real Rate
% r_t = i_t-pi_t+1 
ieqn = 5;
A(ieqn, ipi)     = 1;
B(ieqn, ir)     = -1;
B(ieqn, ii)     = 1;

% Equation #6 Lagged Real Rate
% r_t = r_t 
ieqn =6;
A(ieqn, iil)     = 1;
B(ieqn, ii)     = 1;

% Equation #7 Output Gap
% y_gap = y_t- psi_ya*a_t

ieqn =7;
B(ieqn, iyg)     = -1;
B(ieqn, iy)     = 1;
CF(ieqn, ixA)   =-psi_ya;



% Equation #1 Euler Equation
% define as gap from flexible output
% -c_{t+1} -1/sigma*pi_{t+1} = -c_t -1/sigma*i_t - psi_ya*(a_t^1- a_{t+1})
% to have this version comment off  eq 1 above.

% ieqn = 1; 

% A(ieqn, iyg)       = -1;
% A(ieqn, ipi)       = -1/sigma;
% B(ieqn, iyg)      = -1;
% B(ieqn, ii)      = -1/sigma;
% CF(ieqn, nx + ixA)   =psi_ya; 
% CF(ieqn, ixA)   = -psi_ya; 
