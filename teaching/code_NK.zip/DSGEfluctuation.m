% PhD in Economics Law and Institutions 
% Introduction to DSGE 
% Luca Brugnolini
% January 2015
% King and Watson Toolkit
% Setting up the simulation

clear all;
pause off;
delete('shk.mat')
delete('szshk.mat')
delete('nir.mat')
delete('r.mat')
delete('ch.mat')
delete('tau.mat')
delete('dsgemsens.mat')

% IMPORTANT: below program builds on parameter values that need to be manually 
% defined in system.m and driver.m files.

%-------------------------------------------------------------
% Step 1: run the solution program, with defined tracking option
%-------------------------------------------------------------
track=0;

[M,PI,G,Q,ylist,xlist,lpd]=resolkw('DSGEsys','DSGEdrv',track)
% save modelsol M PI G Q ylist xlist lpd
pause

%-------------------------------------------------------------
% Step 2: compute and graph impulse response function to shock
%-------------------------------------------------------------

fix_seed = 20081126;
randn('seed',fix_seed);
[simu1]=impkwsimu(M,PI,G,ylist,xlist,lpd);
save simu1.mat simu1

[M,PI,G,Q,ylist,xlist,lpd]=resolkw('DSGEsys','DSGEdrv',track)
% save modelsol M PI G Q ylist xlist lpd
pause

%-------------------------------------------------------------
% Step 2: compute and graph impulse response function to shock
%-------------------------------------------------------------

fix_seed = 20081126;
randn('seed',fix_seed);

% Show list of variables
eval('DSGEsys')
yxlist=[ylist; xlist];
sl=size(yxlist);
sl=sl(1);
axislim=[
    0.9 0.9
    0.9 0.9
    0.9 0.9
];
modelname=[
    'DSGE'
    ];
for i=1:sl;
   disp([yxlist(i,:) num2str(i)])
end
% Showing list ends here.
% r = input('Please specify variables to plot >')
ilist1=[1, 4, 5]; % Consumption, Inflation, Nominal Interest Rate

T = 100; % quarters
T0 = T + 8;
simu1 = hp_filter(simu1(5001:5000+T0,ilist1),1600);

simu1ma=zeros(T,length(ilist1));
simu1raw=simu1(1:100,:);


for i=1:T
    simu1ma(i,:)=mean(simu1(i:i+7,:),1);
end


plot_type = input('Type 0 for raw series, type 1 for two-year moving average. >');
ii=0; % index of chart in subplots
for rr=1
    ii=ii+1;
    if plot_type==1
        eval(['plotdata=simu' num2str(rr) 'ma;']);
    elseif plot_type==0
        eval(['plotdata=simu' num2str(rr) 'raw;']);
    end
    Tlist=1:T;
    subplot(1,1,ii);
    hl1 = line(Tlist,plotdata(:,1),'Color','k');
    ax1 = gca;
    set(ax1,'XColor','k','YColor','k',...
         'XLim',[1 T],'YLim',[-axislim(rr,1) axislim(rr,1)])
    hl2 = line(Tlist,plotdata(:,2),'Color','r');
    hl3 = line(Tlist,plotdata(:,3),'Color','b');
    set(ax1, 'XTick', [0:10:T]);
    set(hl1,'LineStyle','--')
    set(hl2,'LineStyle','-')
    set(hl3,'LineStyle','-.')
    set(hl1,'LineWidth',2)
    set(hl2,'LineWidth',2)
    set(hl3,'LineWidth',2)
    set(get(ax1,'XLabel'),'String','Quarter','FontSize',12,'FontAngle','italic', 'FontWeight', 'bold')
    set(get(ax1,'YLabel'),'String','Log-deviation in simulation','FontSize',12, 'FontAngle','italic', 'FontWeight', 'bold')

    if rr==1
        legend('c_t', '\pi_t', 'i_t','FontSize',18)
        legend 
    end
    title(modelname(rr,:),'FontSize',14, 'FontWeight', 'bold')
end
